﻿using BusinessObject.DtoModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Services
{
    public interface IWorkFlow
    {
        void InvokeWorkFlow(Game game);
        void ResumeWorkFlow(Game game);
        void RunPendingWorkFlow(Game game);
    }
}
