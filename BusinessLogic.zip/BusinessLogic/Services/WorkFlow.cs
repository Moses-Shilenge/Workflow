﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Services
{
    public class WorkFlow : IWorkFlow
    {

        public void InvokeWorkFlow(BusinessObject.DtoModels.Game game)
        {
            throw new NotImplementedException();
        }

        public void ResumeWorkFlow(BusinessObject.DtoModels.Game game)
        {
            throw new NotImplementedException();
        }

        public void RunPendingWorkFlow(BusinessObject.DtoModels.Game game)
        {
            throw new NotImplementedException();
        }
    }
}
